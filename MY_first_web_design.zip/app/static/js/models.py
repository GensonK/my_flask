from app import db

class task (db.Model):
    task = db.Column(db.String(250), index=True)
    def __repr__(self):
        return  self.task
