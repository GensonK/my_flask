  <script type="text/javascript">
      var time=moment(new Date(),'YYYY-MM-DD HH:mm:ss').add(1,'s'),o;
      function refreshClock(){
        o = time.add(1,'s').format('YYYY年MM月DD日-dddd HH:mm:ss').split('-');
        $('#ss').html(o[0]);
        $('#bb').html(o[1]);
      };
      window.setInterval(refreshClock, 1000);
  </script>
