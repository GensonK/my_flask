from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_admin import Admin

from flask_login import LoginManager
app = Flask(__name__)
app.config.from_object('config')
db = SQLAlchemy(app)
lm=LoginManager()
lm.init_app(app)
lm.login_view='login'#不让未登录的用户进入除了login之外的界面
admin = Admin(app,template_mode='bootstrap3')

from app import views, models
