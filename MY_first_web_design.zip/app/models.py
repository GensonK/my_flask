from app import db

class Follow(db.Model):
    __tablename__='follows'
    follower_id = db.Column(db.Integer,
                            db.ForeignKey('users.id'),
                            primary_key=True)
    followed_id = db.Column(db.Integer,
                            db.ForeignKey('users.id'),
                            primary_key=True)



class user(db.Model):
    __tablename__='users'
    id  = db.Column(db.Integer,primary_key = True)
    chat_id = db.Column(db.String(64),unique=True,index=True)
    password = db.Column(db.String(250))
    name = db.Column(db.String(250),index=True)
    date = db.Column(db.Date)
    isGroup=db.Column(db.Boolean,index=True)
    gender = db.Column(db.String(250), index=True)
    followed = db.relationship('Follow',
                               foreign_keys=[Follow.follower_id],
                               backref=db.backref('follower',lazy='joined'),
                               lazy='dynamic',
                               cascade='all,delete-orphan')
    follower = db.relationship('Follow',
                               foreign_keys=[Follow.followed_id],
                               backref=db.backref('followed',lazy='joined'),
                               lazy='dynamic',
                               cascade='all,delete-orphan')
    def __repr__(self):
        return  self.chat_id
  
  


        

class chat_record (db.Model):
    __tablename__='record'
    id = db.Column(db.Integer,primary_key=True)
    content = db.Column(db.String(250),index=True)
    date = db.Column(db.DateTime)   #datetime.datetime.now()
    speaker=db.Column(db.String(64),index=True)
    reciever=db.Column(db.String(64),index=True)
    state=db.Column(db.Boolean,index=True,default=False)
    def __repr__(self):
        return  self.content

class log (db.Model):
    __tablename__='log'
    id = db.Column(db.Integer,primary_key=True)
    user=db.Column(db.String(64),index=True)
    action = db.Column(db.String(64),index=True)
    datetime = db.Column(db.DateTime,index=True)   #datetime.datetime.now()

    def __repr__(self):
        return  self.user+self.action
