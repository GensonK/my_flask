from flask_wtf import Form
from wtforms import StringField, BooleanField,  TextAreaField, SelectMultipleField, SelectField,RadioField, PasswordField
from wtforms.fields.html5 import DateField
from wtforms.validators import DataRequired
from wtforms.ext.sqlalchemy.fields import QuerySelectField

from .models import user,chat_record


class UserForm(Form):
    id=StringField('chat_id', validators=[DataRequired()])
    name = StringField('name', validators=[DataRequired()])
    pwd=PasswordField('password', validators=[DataRequired()])
    date = DateField('date', validators=[DataRequired()])
    gender = SelectField('gender', choices=[('male', 'male'), ('female','female') ],
                             validators=[DataRequired()])
    

class LoginForm(Form):
    id=StringField('chat_id', validators=[DataRequired()])
    pwd=PasswordField('password', validators=[DataRequired()])

class SearchForm(Form):
    id=StringField('id', validators=[DataRequired()])

class ChatForm(Form):
    content=TextAreaField('content', validators=[DataRequired()])



class GroupForm(Form):
    group_id = StringField('name', validators=[DataRequired()])
    group_pwd=PasswordField('password', validators=[DataRequired()])
