from flask import render_template, flash, redirect, session, url_for, request, g,get_flashed_messages,session
from flask_admin.contrib.sqla import ModelView
from sqlalchemy import and_,or_
from app import app, db, admin
from .models import user,chat_record,Follow,log
from flask_login import login_user,logout_user,current_user,login_required

from .forms import UserForm, LoginForm,SearchForm,ChatForm,GroupForm
import datetime
admin.add_view(ModelView(user, db.session))


@app.route('/')
def page():

    if session.get('id') == None:
        return redirect('/login')
    else:
        return redirect('/welcome')



@app.route('/login', methods=['GET','POST'])
def login():
    
    form = LoginForm()
    if form.validate_on_submit():
        num=form.id.data
        password=form.pwd.data
        log_user=user.query.filter(and_(user.chat_id==num,user.password==password)).first()
        
        if log_user is None :
            flash('Invalid username or password')
        else:
            if num=='genson':
                return redirect('/admin_genson')
            session['id']=num
  
            t=log(user=session.get('id'),action='log in',datetime=datetime.datetime.now())
            db.session.add(t)
            db.session.commit()

            return redirect(url_for('welcome'))  
    return render_template('login.html',
                           form=form)###add flash message




@app.route('/exit', methods=['GET','POST'])
def exit():
    session.clear()
    t=log(user=session.get('id'),action='log out',datetime=datetime.datetime.now())
    db.session.add(t)
    db.session.commit()
    return redirect('/login')



@app.route('/welcome', methods=['GET','POST'])
def welcome():
    
    groups=[]#user's followed groups
    friends=[]#user's followed firends

    follower_id_this=[]
    followed_id_this=[]
    new_followers=[]

    new_messages=[]


    user_this= user.query.filter(user.chat_id==session.get('id')).first()

    followeds=Follow.query.filter(Follow.follower_id==user_this.id).all()#get all relationships for user as follower
    followers=Follow.query.filter(Follow.followed_id==user_this.id).all()#get all relationships for user as followed


    unreads=chat_record.query.filter(and_(chat_record.state==False,chat_record.reciever==user_this.chat_id)).all()
    
    for i in Follow.query.filter(Follow.followed_id==user_this.id).all():
        follower_id_this.append(i.follower_id)#all followers' id of user
        
    for i in Follow.query.filter(Follow.follower_id==user_this.id).all():
        followed_id_this.append(i.followed_id)#all followeds' id of user
    for i in follower_id_this:
        if i not in followed_id_this:
            new_followers.append(user.query.filter(user.id==i).first())

        
    for item in followeds:
        one =user.query.filter(user.id==item.followed_id).first()
        if one !=None:
            if one.isGroup is True:#define if it's a group
                groups.append(one)
            else:
                friends.append(one)

    for i in unreads:
        j=user.query.filter(user.chat_id==i.speaker).first()
        if j not in new_messages:
            new_messages.append(j)
    

    
    return render_template('welcome.html',
                           title='Hello',
                           friends=friends,
                           groups=groups,
                           new_followers=new_followers,
                           new_messages=new_messages,
                           user_this=user_this)
    


@app.route('/register', methods=['GET','POST'])
def register():
    form = UserForm()
    if form.validate_on_submit():
        if user.query.filter(user.chat_id==form.id.data).first()!=None:
            flash('account exists')
        else:
            t = user(chat_id=form.id.data,
                 password=form.pwd.data,
                 name=form.name.data,
                 date=form.date.data,
                 gender=form.gender.data)
            db.session.add(t)
            db.session.commit()
            return redirect('/')
            t=log(user=session.get('id'),action='register done',datetime=datetime.datetime.now())
            db.session.add(t)
            db.session.commit()
    return render_template('register.html',
                           title='Register you own chat ID',
                           form=form)






@app.route('/friend_chat/<id>', methods=['GET','POST'])
def friend_chat(id):
    session['friend']=id
    user_this= user.query.filter(user.chat_id==session.get('id')).first()
    friend_this= user.query.filter(user.chat_id==id).first()
    form = ChatForm()

    reads=chat_record.query.filter(and_(chat_record.speaker==friend_this.chat_id ,chat_record.reciever==user_this.chat_id)).all()
    for read in reads:
        read.state=True
        db.session.commit()
 


    user_speak = chat_record.query.filter(or_(and_(chat_record.speaker==user_this.chat_id , chat_record.reciever==session.get('friend')),
                                              and_(chat_record.speaker==session.get('friend') , chat_record.reciever==user_this.chat_id))).order_by(-chat_record.id).all()
   
    
    if form.validate_on_submit():
        t=chat_record(content=form.content.data,
                    speaker=user_this.chat_id,
                    reciever=session.get('friend'),
                    date=datetime.datetime.now())
        db.session.add(t)
        db.session.commit()
        t=log(user=session.get('id'),action='send to '+id,datetime=datetime.datetime.now())
        db.session.add(t)
        db.session.commit()
        return redirect(url_for('friend_chat',id=session.get('friend')))
    return render_template('friend_chat_page.html',
                           tittle='friend chat page',
                           form=form,
                           says=user_speak,
                           friend_this=friend_this,
                           user_this=user_this
                          )


@app.route('/group_chat/<id>', methods=['GET','POST'])
def group_chat(id):
    session['group']=id
    form = ChatForm()
   
    user_this=user.query.filter(user.chat_id==session.get('id')).first()
    group_this=user.query.filter(user.id==session.get('group')).first()

    group_chats = chat_record.query.filter( chat_record.reciever==session.get('group')).all()
    if form.validate_on_submit():
        t=chat_record(content=form.content.data,
                    speaker=user_this.chat_id,
                    reciever=session.get('group'),
                    date=datetime.datetime.now())
        db.session.add(t)
        db.session.commit()
        t=log(user=session.get('id'),action='chat in group'+ id,datetime=datetime.datetime.now())
        db.session.add(t)
        db.session.commit()
        return redirect(url_for('group_chat',id=session.get('group')))
    return render_template('group_chat_page.html',
                           tittle='group chat page',
                           form=form,
                           says=group_chats,
                           group=group_this,
                           )

    
@app.route('/add_contact/<id>', methods=['GET','POST'])
def add_contact(id):
    user_this=user.query.filter(user.chat_id==session.get('id')).first()
    user_id=user_this.id
    t=Follow(follower_id=user_id,followed_id=id)
    db.session.add(t)
    db.session.commit()
    t=log(user=session.get('id'),action='add friend done',datetime=datetime.datetime.now())
    db.session.add(t)
    db.session.commit()
    return redirect('/welcome') 
    
    

@app.route('/delete_contact/<id>', methods=['GET','POST'])
def delete_contact(id):
    user_this=user.query.filter(user.chat_id==session.get('id')).first()
    t=Follow.query.filter(Follow.follower_id==user_this.id,Follow.followed_id==id).first()
    db.session.delete(t)
    db.session.commit()
    t=log(user=session.get('id'),action='delete friend done',datetime=datetime.datetime.now())
    db.session.add(t)
    db.session.commit()
    return redirect('/welcome') 
    
    

@app.route('/create_group', methods=['GET','POST'])
def create_group():

    form = GroupForm()
    if form.validate_on_submit():
        if user.query.filter(user.chat_id==form.group_id.data).first()!=None:
            flash('account un-available')
        else:
            t = user(chat_id=form.group_id.data,
                 password=form.group_pwd.data,
                 date=datetime.datetime.today(),
                 isGroup=True)
            db.session.add(t)
            db.session.commit()
            t=log(user=session.get('id'),action='create group done',datetime=datetime.datetime.now())
            db.session.add(t)
            db.session.commit()
            return redirect('/welcome') 
    return render_template('create_group.html',
                           title='Create a group',
                           form=form)





@app.route('/search', methods=['GET','POST'])
def search():
    form = SearchForm()
    if form.validate_on_submit():
        user_id=session.get('id')
        followed=form.id.data
        user_this=user.query.filter(user.chat_id==user_id).first()
        search_result=user.query.filter(user.chat_id==followed).first()
        if search_result == None:
            flash('can not find this ID')
            
        else:
            if search_result.isGroup is True:
                type="chat group"
            else:
                type="user"




            if Follow.query.filter(Follow.follower_id==user_this.id,Follow.followed_id==search_result.id).first() is None:
                state1 = 'add'
                return render_template('search.html',
                           title='search',
                           form=form,
                           result=search_result,
                           state1=state1,
                           type=type
                           )
            else:
                state2 = 'delete'
                return render_template('search.html',
                           title='search',
                           form=form,
                           result=search_result,
                           state2=state2,
                           type=type
                           )
            t=log(user=session.get('id'),action='search done',datetime=datetime.datetime.now())
            db.session.add(t)
            db.session.commit()

            
    return render_template('search.html',
                           title='search',
                           form=form
                           )



@app.route('/admin_genson', methods=['GET','POST'])
def admin_genson():
    logs=log.query.filter().all()
    return render_template('log.html',
                           logs=logs
                           )