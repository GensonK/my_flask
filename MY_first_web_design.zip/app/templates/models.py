from app import db


db.drop_all()
db.create_all()
class user(db.Model):
    id=db.Column(db.Integer,primary_key = True)

    chat_num = db.Column(db.String(250))
    password = db.Column(db.String(250),index=True)
    name = db.Column(db.String(250),index=True)
    date = db.Column(db.Date,index=True)
    gender = db.Column(db.String(250), index=True)
    def __repr__(self):
        return  self.chat_num