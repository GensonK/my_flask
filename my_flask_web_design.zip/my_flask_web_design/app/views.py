from flask import render_template, flash, redirect, session, url_for, request, g,get_flashed_messages
from flask_admin.contrib.sqla import ModelView

from app import app, db, admin
from .models import tasks


from .forms import TaskForm

admin.add_view(ModelView(tasks, db.session))


@app.route("/")
def homepage():
    return render_template('index.html',
                            title='homepage')

@app.route('/add_task', methods=['GET','POST'])
def add_task():
    form = TaskForm()
    if form.validate_on_submit():
        t = tasks(task=form.task.data,mark=form.mark.data,date=form.date.data)
        db.session.add(t)
        db.session.commit()
        return redirect('/get_all_tasks')  #redirect
    return render_template('add_task.html',
                           title='Add Task',
                           form=form)

@app.route('/delete_task/<id>', methods=['GET','POST'])
def delete_task(id):
    task=tasks.query.get(id)#find the task from db
    db.session.delete(task)
    db.session.commit()
    return redirect('/get_all_tasks')


@app.route("/get_all_tasks", methods=['GET'])
def get_all_tasks():
    ts = tasks.query.all()
    form=TaskForm()
    return render_template('tasks.html',
                           title='All Tasks',
                           tasks=ts,
                           form=form)

@app.route('/get_all_uncompleted_tasks', methods=['GET','POST'])
def get_all_uncompleted_tasks():
    id="uncompleted"
    form = TaskForm()
    ts = tasks.query.filter_by(mark=id).all()
    return render_template('tasks.html',  #Fully reuse html--Incoming different data but use the same html
                           title='Uncompleted Tasks',
                           tasks=ts,
                           form=form)

@app.route('/get_all_completed_tasks', methods=['GET'])
def get_all_completed_tasks():
    id = "completed"
    form = TaskForm()
    ts = tasks.query.filter_by(mark=id).all()
    return render_template('tasks.html',
                           title='All Completed Tasks',
                           tasks=ts,
                           form=form)

@app.route('/change_performance/<id>', methods=['GET','POST'])
def change_performance(id):
    ts = tasks.query.get(id)
    if ts.mark=="completed":
        t=tasks(task=ts.task,mark="uncompleted",date=ts.date)#rewrite db  
        db.session.add(t)
        db.session.delete(ts)
        db.session.commit()

        return redirect('/get_all_uncompleted_tasks')
    else:
        t=tasks(task=ts.task,mark="completed",date=ts.date)
        db.session.add(t)
        db.session.delete(ts)
        db.session.commit()
        return redirect('/get_all_completed_tasks')
