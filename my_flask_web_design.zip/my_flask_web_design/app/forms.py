from flask_wtf import Form
from wtforms import StringField, BooleanField,  TextAreaField, SelectMultipleField, SelectField,RadioField
from wtforms.fields.html5 import DateField
from wtforms.validators import DataRequired
from wtforms.ext.sqlalchemy.fields import QuerySelectField

from .models import tasks


class TaskForm(Form):
    task = StringField('task', validators=[DataRequired()])
    date = DateField('date', validators=[DataRequired()])
    mark = SelectField('state', choices=[('completed', 'completed'), ('uncompleted', 'uncompleted'), ], validators=[DataRequired()])


