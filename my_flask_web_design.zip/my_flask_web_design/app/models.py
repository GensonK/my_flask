from app import db



class tasks(db.Model):
    id=db.Column(db.Integer,primary_key = True)
    task = db.Column(db.String(250))
    date = db.Column(db.Date,index=True)
    mark = db.Column(db.String(250),index=True)
    def __repr__(self):
        return  self.task


